import * as React from 'react';

interface pp {
  name: ''
}

class Test extends React.Component<pp> {
  render() {
    return(
      <h1>Hello</h1>
    );
  }
}

export default Test;