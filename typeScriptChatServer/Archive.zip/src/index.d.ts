export interface Message {
	name: string;
	message: string;
}